package com.example.retrofitforecaster

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import okhttp3.OkHttpClient

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}
override fun getOkHttpClientBuilder(): OkHttpClient.Builder {
    val okHttpBuilder = super.getOkHttpClientBuilder()
    okHttpBuilder.addInterceptor { chain ->
        val request = chain.request().newBuilder()
        val originalHttpUrl = chain.request().url
        val url = originalHttpUrl.newBuilder().addQueryParameter("api_key", "5709ead825092b65274d68984fe3ec54").build()
        request.url(url)
        val response = chain.proceed(request.build())
        return@addInterceptor response
    }
    return okHttpBuilder
}